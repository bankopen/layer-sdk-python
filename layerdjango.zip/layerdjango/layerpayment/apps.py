from django.apps import AppConfig


class LayerpaymentConfig(AppConfig):
    name = 'layerpayment'
